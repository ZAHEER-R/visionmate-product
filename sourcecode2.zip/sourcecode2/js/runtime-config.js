globalThis.VISIONMATE_CONFIG = Object.freeze({"supabase":{"url":"https://your_project.supabase.co"}});
