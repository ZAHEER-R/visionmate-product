# VisionMate

VisionMate is a mobile-first, installable web app for blind and low-vision users. It combines voice-first interaction with an optional camera assistant, text reading, translation, notes, reminders, route estimates, profile settings, and an emergency contact screen.

**Live app:** [https://visionmate.vercel.app](https://visionmate.vercel.app)

The app is designed for mobile browsers and can be installed as a PWA. It is a website, not a native Android application: it cannot scan or control other installed apps, access hardware volume-button holds, grant OS permissions, or display over other apps.

## Features

- **Voice interaction:** Browser speech recognition, an on-screen press-and-hold Talk button, optional recorded WAV speech recognition, typed commands, and queued spoken responses. Speech output can use the device voice or Gemini voice.
- **Seven spoken languages:** English, Hindi, Tamil, Telugu, Kannada, Malayalam, and Punjabi. Gemini voice mode translates the text and generates speech in the selected language. Device speech requires a matching installed system voice.
- **Vision Lens:** User-started camera preview, front/rear camera switching, supported hardware/digital zoom, fullscreen, and one-frame Gemini questions or reading. The camera status reflects whether the preview is active.
- **Go:** With explicit consent, requests current location and destination, estimates walking distance/time through Photon and Valhalla, and displays the returned route geometry on an OpenStreetMap/Leaflet map.
- **Accessible assistant tools:** Local and optional cloud-synced profile, chat history, notes, reminders, activity/insights, translation, trusted contacts, and an emergency screen.
- **Guest use:** Continue without Firebase sign-in. Guest information is stored locally in the current browser and is not account-synced.
- **PWA/offline entry:** The service worker caches the app shell and optional emergency screen. AI and route services still need an internet connection.
- **Profile controls:** Expand/collapse, edit, language and voice settings, and recent chat history.

## Accessibility, gestures, and permissions

- Use the fixed bottom navigation for **Back**, **Home**, **Go**, **Lens**, **Voice**, and **Me**. Use the visible Talk button by pressing and holding while speaking, then release to stop.
- Voice and typed commands can open supported VisionMate screens and features. The app does not have general-purpose phone or other-app control.
- Camera and microphone access are requested only when their feature is started. Location is requested only after consenting to a route estimate. The browser/operating system presents and controls permission dialogs.
- Map touch gestures are provided by Leaflet. The app avoids native dragging on its controls; vertical page scrolling and browser pinch zoom remain available.
- Automatic speech may be blocked until the first user interaction by browser autoplay rules. Browser speech recognition and installed voices vary by device.
- “Display over other apps,” Android accessibility services, background wake-word listening, and hardware volume-button shortcuts require a separately developed native Android app and explicit OS permissions. VisionMate does not show fake browser permission prompts for these capabilities.

### Safety and privacy limits

Camera analysis sends a still image to the configured Gemini service only when the user requests analysis; optional periodic snapshots operate only while that feature is enabled and the page remains open. Images and AI results can be wrong. The web app is not a local Python/OpenCV vision system, cannot reliably detect hazards or people-related risks, and must not be used to guide walking or crossing roads.

The route shown is an approximate public pedestrian route and is not checked for sidewalks, accessibility, closures, or hazards. It is not turn-by-turn guidance and does not establish that a route is safe. Continue using a cane, guide dog, validated navigation aid, and trusted assistance. Do not use VisionMate to decide whether a path or crossing is safe.

The people-privacy preference asks the model not to describe or identify people; it does not blur pixels. Avoid capturing people or private material without consent. External phone, contact, or website actions are user-initiated and require confirmation where offered.

## Technology and connections

| Technology / service | Purpose | Main implementation |
|---|---|---|
| HTML, CSS, browser JavaScript ES modules | Frontend; no root frontend bundler/build step | `index.html`, `css/`, `js/` |
| Firebase Authentication Web SDK | Optional Google and email/password sign-in | `js/firebase.js`, `js/auth.js` |
| Firebase Cloud Functions v2 and Admin SDK | Adds the Supabase-required authenticated role claim for signed-in account sync | `functions/index.js` |
| Supabase Auth anonymous session | Authenticates protected Edge Function requests for guest AI/translation | `js/supabase.js` |
| Supabase Postgres, RLS, Firebase third-party Auth | Optional account data and row isolation by Firebase UID | `supabase/migrations/`, Supabase Auth settings |
| Firebase Realtime Database | Optional signed-in profile mirror when `FIREBASE_DATABASE_URL` is configured | `js/firebase.js`, `database.rules.json` |
| Supabase Edge Functions (Deno/TypeScript) | Server-side proxy for Gemini, Bhashini, and Anuvaadhub; keeps private provider keys off the browser | `supabase/functions/` |
| Gemini API | Assistant and vision responses, command interpretation, and multilingual generated speech (`gemini-3.8-flash-lite-tts`; text is translated before synthesis) | `supabase/functions/gemini-assist/index.ts` |
| Anuvaadhub | Provider-backed translation, recorded WAV ASR, TTS, and OCR where enabled by the configured model catalog | `supabase/functions/anuvaadhub-inference/` |
| Bhashini | Translation provider | `supabase/functions/bhashini-translate/` |
| Browser Web APIs | Camera, speech recognition/synthesis, audio, location, notifications, and phone handoff | `js/camera.js`, `js/speech.js`, `js/app.js` |
| Leaflet and OpenStreetMap | Interactive route map and map tiles | `index.html`, `js/app.js` |
| Photon and Valhalla | Consent-gated geocoding and approximate pedestrian route geometry, distance, and time | `js/routes.js` |
| Service worker and web manifest | Installable PWA and cached app shell | `sw.js`, `manifest.json` |
| Vercel / Firebase Hosting | Static web deployment options | repository root, `firebase.json` |

### System architecture

1. The browser loads the static app, generated public runtime configuration, CSS, and JavaScript modules.
2. The user can use local guest features without Firebase. Optional Firebase sign-in identifies an account; Firebase ID tokens are used for Supabase account-data requests.
3. Cloud assistant and language requests obtain a Supabase anonymous Auth session and call JWT-protected Supabase Edge Functions. Those functions read private API keys from Supabase secrets and call the configured providers.
4. Supabase Postgres stores account records under row-level security when account sync is configured. Guest data remains in local browser storage.
5. Location and destination are sent to Photon/Valhalla only after route consent. Returned coordinates and route geometry are drawn by Leaflet using OpenStreetMap tiles.

### Data storage

| Store | Data | When used |
|---|---|---|
| Browser local storage | Guest profile, settings, notes, reminders, chat history, and device-only preferences | Guest mode and local fallback |
| Supabase Postgres | `profiles`, `notes`, `contacts`, `reminders`, `user_settings`, `assistant_conversations`, `assistant_messages`, and `activity_events` | Signed-in account sync with row-level security |
| Firebase Realtime Database | Optional signed-in profile mirror under `users/{uid}/profile` | Only when `FIREBASE_DATABASE_URL` is configured and RTDB rules are deployed |
| Service-worker cache | App shell and optional emergency-screen entry | PWA/offline shell; not an AI or route database |

Cloud availability depends on valid runtime configuration, enabled Supabase anonymous sign-in, deployed functions, provider secrets, and provider quota/model access. A successful local guest session does not imply cloud AI is configured.

## API keys and configuration

Variable names below are placeholders, not credentials. Public browser values are visible to visitors; provider secrets must stay server-side. Never commit real keys or paste them into browser code, chat, or the public `js/runtime-config.js`.

### Public browser configuration

Set values in the root `.env` for local development or in the hosting provider’s environment settings. Run `node scripts/build-config.mjs` to generate ignored `js/runtime-config.js`.

| Variable | Use | Classification |
|---|---|---|
| `SUPABASE_URL` | Supabase project endpoint used by the browser client | Public |
| `SUPABASE_ANON_KEY` | Supabase publishable/anon key; database access still depends on RLS | Public |
| `FIREBASE_API_KEY` | Firebase Web App configuration for optional sign-in | Public config |
| `FIREBASE_AUTH_DOMAIN` | Firebase web authentication domain | Public config |
| `FIREBASE_PROJECT_ID` | Firebase project identity | Public config |
| `FIREBASE_APP_ID` | Firebase Web App identity | Public config |
| `FIREBASE_DATABASE_URL` | Optional Firebase Realtime Database endpoint | Public config |
| `GOOGLE_OAUTH_CLIENT_ID` | Documentation/setup placeholder; current browser code does not read it | Not consumed by app |

Do not put a Supabase service-role key or Firebase Admin/service-account credential in frontend config.

### Server-only provider secrets

Set provider keys with `supabase secrets set NAME=value` or in Supabase Dashboard → Edge Functions → Secrets.

| Secret / variable | Use |
|---|---|
| `GEMINI_API_KEY` | Private Gemini credential for assistant, vision, intent, speech translation, and TTS requests |
| `GEMINI_MODELS` | Comma-separated assistant and speech-translation model allowlist/fallback order; TTS uses `gemini-3.8-flash-lite-tts` |
| `BHASHINI_USER_ID`, `BHASHINI_API_KEY`, `BHASHINI_PIPELINE_ID` | Bhashini translation credentials and configured pipeline |
| `ANUVAADHUB_ACCESS_TOKEN_EN` | Anuvaadhub English model access |
| `ANUVAADHUB_ACCESS_TOKEN_HI` | Anuvaadhub Hindi model access |
| `ANUVAADHUB_ACCESS_TOKEN_TA` | Anuvaadhub Tamil model access |
| `ANUVAADHUB_ACCESS_TOKEN_TE` | Anuvaadhub Telugu model access |
| `ANUVAADHUB_ACCESS_TOKEN_KN` | Anuvaadhub Kannada model access |
| `ANUVAADHUB_ACCESS_TOKEN_ML` | Anuvaadhub Malayalam model access |
| `ANUVAADHUB_ACCESS_TOKEN_PA` | Anuvaadhub Punjabi model access |
| `ANUVAADHUB_ACCESS_TOKEN` | Optional legacy shared-token fallback |

The seven Anuvaadhub entries are independent server-side token slots. They do not replace `GEMINI_API_KEY`; Gemini uses its own provider credential. The blank template is [supabase/.env.example](./supabase/.env.example). Copy it to ignored `supabase/.env` and paste secrets there, then deploy them with the Supabase CLI. Provider model access can expire independently of a token; refresh the approved model catalog before its listed grants expire.

## Setup and deployment

For the shortest setup, follow [my Firebase and Supabase setup instructions](./my%20Firebase%20and%20Supabase%20setup%20instructions.md). A fuller outline follows.

### 1. Configure the static frontend

1. Install Node.js (the Functions package targets Node 20).
2. Copy `.env.example` to `.env`. Set `SUPABASE_URL` and `SUPABASE_ANON_KEY`; add Firebase Web App values only if you want account sign-in.
3. Run `node scripts/build-config.mjs`. The script writes the public values to ignored `js/runtime-config.js`.
4. For Vercel, import the repository, set the same public environment variables in Project Settings, use `node scripts/build-config.mjs` as the build command, and use `.` as the output directory. Deploy over HTTPS.

There is no root `package.json` and no frontend `npm install` step. Firebase Web SDK modules are loaded from a pinned CDN. `npm install firebase` is only needed if you later move the frontend SDK into an npm-managed build.

### 2. Optional Firebase sign-in and Hosting

1. Create a Firebase project and Web App; enable Google and/or Email/Password in Firebase Authentication.
2. Add `visionmate.vercel.app` and your local development host to Firebase Authentication’s authorized domains.
3. Add the Web App values to root `.env` or hosting environment variables and regenerate runtime configuration.
4. Firebase Realtime Database is optional. For profile mirroring, set `FIREBASE_DATABASE_URL` and deploy `database.rules.json`; it is not required for Supabase data or guest mode.
5. For Supabase account sync, configure Firebase as a third-party Auth provider in Supabase and deploy the Firebase callable:

   ```powershell
   Set-Location functions
   npm install
   Set-Location ..
   firebase deploy --only functions:ensureSupabaseRole
   ```

   Cloud Functions deployment may require a billing-enabled Firebase project. Admin SDK credentials use Firebase-managed service identity; do not download a service-account file for the frontend.
5. To deploy the existing Firebase Hosting configuration, install/use the CLI (`npm install -g firebase-tools`), run `firebase login`, then `firebase deploy --only hosting`. This repository already has `firebase.json`; do not run `firebase init` over it unless intentionally creating a new hosting configuration.

### 3. Supabase Auth, database, and Edge Functions

1. Create a Supabase project. Enable **Anonymous Sign-Ins** in Authentication → Sign In / Providers. This session is used for protected cloud AI and language functions, including when the person uses local guest mode.
2. Link the project and apply migrations:

   ```sh
   supabase login
   supabase link --project-ref YOUR_SUPABASE_PROJECT_REF
   supabase db push
   ```

   Apply `supabase/migrations/202610110001_visionmate.sql` and then `supabase/migrations/202610110002_firebase_identity.sql`. The Firebase UID migration and Firebase third-party provider are for account-sync users; guest AI only needs the anonymous Supabase session.
3. Set provider secrets. For a quick local secret file, copy `supabase/.env.example` to `supabase/.env`, fill its seven Anuvaadhub values, and run:

   ```sh
   supabase secrets set --env-file supabase/.env
   supabase secrets set GEMINI_API_KEY=YOUR_GEMINI_KEY
   supabase secrets set GEMINI_MODELS=gemini-2.5-flash,gemini-2.5-flash-lite
   ```

   Set Bhashini variables only if using that translation provider. Do not use the root `.env` for private provider keys.
4. Deploy protected functions:

   ```sh
   supabase functions deploy gemini-assist
   supabase functions deploy bhashini-translate
   supabase functions deploy anuvaadhub-inference
   ```

   JWT verification remains enabled in `supabase/config.toml`. Do not disable it to hide Auth setup problems.

#### Supabase Google OAuth callback

If you configure Google as a **Supabase Auth provider**, the Supabase callback for this project is:

`https://bwxvnkutnjagqsivuqbz.supabase.co/auth/v1/callback`

Add that exact URI to the Google OAuth client’s **Authorized redirect URIs**, then enter the Google client ID/secret in Supabase’s Google provider settings. This callback is not a Firebase callback and is not used by the current Firebase Google-popup sign-in flow. For Firebase popup sign-in, configure the OAuth provider and authorized domains in Firebase instead.

### 4. Verify and troubleshoot

- Open the app over HTTPS and test the guest flow; test a camera prompt only after user initiation.
- If cloud calls fail, verify the public Supabase URL/key, Anonymous Sign-Ins, deployed functions, JWT verification, provider secrets, model access, and Edge Function logs.
- If account sync fails, separately verify Firebase sign-in, Firebase third-party Auth integration in Supabase, the role-claim callable, applied migrations, and RLS.
- If route lookup fails, check location permission and network access to Photon, Valhalla, and OpenStreetMap tiles.
- Speech recognition and device voices vary by browser. Gemini voice requires working Supabase Edge Functions, a valid `GEMINI_API_KEY`, network access, and Gemini TTS model access. The device voice fallback is used only when a matching installed voice is available (or for English).
- An Android overlay or hardware-button permission cannot be enabled from this website.

## File map

| File / folder | Purpose |
|---|---|
| `index.html` | App document, PWA metadata, CDN dependencies, runtime config and JS entry point |
| `assets/logo.png` | Brand mark used by the app |
| `css/styles.css` | Responsive light/orange theme, app layout, route map, controls and accessibility styling |
| `js/app.js` | Screens, navigation, voice command dispatch, app workflows, settings and event handlers |
| `js/config.js` | Public runtime defaults and supported language/voice locale mapping |
| `js/runtime-config.js` | Generated public browser config; ignored and not committed |
| `js/auth.js`, `js/firebase.js` | Guest/profile handling and optional Firebase sign-in |
| `database.rules.json` | Firebase Realtime Database access rules for the optional profile mirror |
| `js/supabase.js` | Supabase clients, Edge Function calls and account-record persistence |
| `js/speech.js` | Serialized speech output, Gemini speech audio, browser voice selection and recognition |
| `js/camera.js`, `js/cv.js` | Camera preview controls and image-analysis helpers |
| `js/routes.js` | Consent-gated Photon/Valhalla search, route data and polyline decoding |
| `js/mt.js`, `js/anuvaadhub.js`, `js/stt.js`, `js/tts.js` | Translation and Anuvaadhub ASR/TTS integration |
| `js/intent.js` | Local assistant response/fallback helper |
| `supabase/config.toml` | Supabase local configuration and Edge Function JWT settings |
| `supabase/migrations/` | Postgres tables, indexes, policies, and Firebase identity migration |
| `supabase/functions/gemini-assist/index.ts` | Server-side Gemini assistant, vision, intent and generated-speech endpoint |
| `supabase/functions/bhashini-translate/index.ts` | Bhashini translation proxy |
| `supabase/functions/anuvaadhub-inference/index.ts` | Anuvaadhub MT/ASR/TTS/OCR proxy |
| `supabase/functions/_shared/` | Shared CORS and approved Anuvaadhub model catalog |
| `supabase/.env.example` | Blank per-language Anuvaadhub secret template |
| `functions/index.js`, `functions/package.json` | Firebase callable and its isolated Node dependencies |
| `scripts/build-config.mjs` | Creates ignored public `js/runtime-config.js` |
| `.env.example` | Root public-config template and server-secret reminders |
| `manifest.json`, `sw.js` | PWA install metadata and service-worker cache behavior |
| `firebase.json`, `database.rules.json` | Firebase Hosting and optional Realtime Database configuration |
| `my Firebase and Supabase setup instructions.md` | Short project-specific setup checklist |

## Project limitations

Browser support determines camera, voice, location, notification, and offline capabilities. Background reminders are not guaranteed after the browser closes. Emergency phone actions hand off to the device and are not emergency-service dispatch. Public routing, visual analysis, generated speech, and AI responses may be unavailable, delayed, or incorrect.
